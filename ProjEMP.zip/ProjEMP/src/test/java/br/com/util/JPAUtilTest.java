package br.com.util;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JPAUtilTest {
	
private EntityManager em;
    @Test
    public void deveTerInstanciaDoEntityManagerDefinida(){
    	assertNotNull("instancia do EntityManager n�o deve estar nula", em);
    }
    @Test
    public void deveFecharEntityManager(){
    	em.close();
    	
    	assertFalse("instancia do EntityManager deve estar fechada", em.isOpen());
    }
    
    @Test
    public void deveAbrirUmaTransacao(){
    	assertFalse("transa��o deve estar fechada", em.getTransaction().isActive());
    	
    	em.getTransaction().begin();
    	
    	assertTrue("transa��o deve estar aberta", em.getTransaction().isActive());
    }
    @Before
    public void instanciarEntityManager(){
    	em = JPAUtil.INSTANCE.getEntityManager();
    }
    
    @After
    public void fecharEntityManager(){
    	if (em.isOpen()) {
			em.close();
		}
    }

}
